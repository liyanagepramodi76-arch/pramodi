
import { auth, db } from "./firebase-config.js";

import { onAuthStateChanged } from
    "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

import {
    collection,
    query,
    where,
    onSnapshot,
    doc,
    updateDoc,
    writeBatch
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

const notificationList = document.getElementById("notificationList");
const notificationMessage = document.getElementById("notificationMessage");
const markAllReadButton = document.getElementById("markAllRead");

let currentNotifications = [];

const icons = {
    registration: "bi-person-plus",
    stock: "bi-box-seam",
    price: "bi-tags",
    request: "bi-chat-square-text"
};

onAuthStateChanged(auth, (user) => {
    if (!user) {
        window.location.replace("login.html");
        return;
    }

    loadNotifications(user.uid);
});

function loadNotifications(uid) {
    const notificationQuery = query(
        collection(db, "notifications"),
        where("userId", "==", uid)
    );

    onSnapshot(notificationQuery, (snapshot) => {
        currentNotifications = snapshot.docs.map((item) => ({
            id: item.id,
            ...item.data()
        }));

        currentNotifications.sort((a, b) => {
            const dateA = a.createdAt?.toMillis?.() || 0;
            const dateB = b.createdAt?.toMillis?.() || 0;
            return dateB - dateA;
        });

        displayNotifications();

        const unread = currentNotifications.filter(
            item => item.read !== true
        ).length;

        notificationMessage.textContent =
            `${currentNotifications.length} notifications • ${unread} unread`;

    }, (error) => {
        console.error("Notification loading error:", error);
        notificationMessage.textContent =
            "Unable to load notifications. Check Firestore permissions.";
        notificationList.textContent = "Could not load notifications.";
    });
}

function displayNotifications() {
    notificationList.replaceChildren();

    if (currentNotifications.length === 0) {
        const empty = document.createElement("div");
        empty.className = "empty-message";
        empty.textContent = "You don't have any notifications yet.";
        notificationList.appendChild(empty);
        return;
    }

    currentNotifications.forEach((item) => {
        const card = document.createElement("article");
        card.className = "notification-item " +
            (item.read === true ? "read" : "unread");

        const iconBox = document.createElement("div");
        iconBox.className = "notification-icon";

        const icon = document.createElement("i");
        icon.className = "bi " + (icons[item.type] || "bi-bell");
        iconBox.appendChild(icon);

        const details = document.createElement("div");
        details.className = "notification-details";

        const title = document.createElement("h3");
        title.textContent = item.title || "Notification";

        const message = document.createElement("p");
        message.textContent = item.message || "";

        const date = document.createElement("span");
        date.className = "notification-date";

        const timestamp = item.createdAt?.toDate?.();
        date.textContent = timestamp
            ? timestamp.toLocaleString()
            : "Just now";

        details.append(title, message, date);
        card.append(iconBox, details);

        if (item.read !== true) {
            const button = document.createElement("button");
            button.type = "button";
            button.className = "read-button";
            button.textContent = "Mark as read";

            button.addEventListener("click", async () => {
                button.disabled = true;

                try {
                    await updateDoc(
                        doc(db, "notifications", item.id),
                        { read: true }
                    );
                } catch (error) {
                    console.error("Unable to mark notification as read:", error);
                    alert("Unable to update notification. Please try again.");
                    button.disabled = false;
                }
            });

            card.appendChild(button);
        } else {
            const readLabel = document.createElement("span");
            readLabel.className = "notification-date";
            readLabel.textContent = "Read";
            card.appendChild(readLabel);
        }

        notificationList.appendChild(card);
    });
}

markAllReadButton.addEventListener("click", async () => {
    const unreadItems = currentNotifications.filter(
        item => item.read !== true
    );

    if (unreadItems.length === 0) {
        alert("There are no unread notifications.");
        return;
    }

    markAllReadButton.disabled = true;

    try {
        const batch = writeBatch(db);

        unreadItems.forEach((item) => {
            batch.update(doc(db, "notifications", item.id), {
                read: true
            });
        });

        await batch.commit();
    } catch (error) {
        console.error("Unable to mark all as read:", error);
        alert("Unable to update notifications. Please try again.");
    } finally {
        markAllReadButton.disabled = false;
    }
});
