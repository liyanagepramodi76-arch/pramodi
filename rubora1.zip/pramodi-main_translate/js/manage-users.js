
import { auth, db } from "./firebase-config.js";

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

import {
    collection,
    getDocs,
    doc,
    deleteDoc
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

const usersTableBody = document.getElementById("usersTableBody");
const userSearch = document.getElementById("userSearch");
const userTypeFilter = document.getElementById("userTypeFilter");
const usersMessage = document.getElementById("usersMessage");

let allUsers = [];

// ADMIN SECURITY
onAuthStateChanged(auth, async (user) => {

    if (!user) {
        window.location.replace("login.html");
        return;
    }

    try {
        const tokenResult = await user.getIdTokenResult(true);

        if (tokenResult.claims.admin !== true) {
            alert("Access denied! Admin permission required.");
            await signOut(auth);
            window.location.replace("login.html");
            return;
        }

        await loadUsers();

    } catch (error) {
        console.error("Admin verification error:", error);
        alert("Unable to verify administrator access.");
        await signOut(auth);
        window.location.replace("login.html");
    }
});

// LOAD USERS FROM FIRESTORE
async function loadUsers() {

    usersMessage.textContent = "Loading users...";

    try {
        const snapshot = await getDocs(collection(db, "users"));

        allUsers = [];

        snapshot.forEach((document) => {
            const data = document.data();

            if (data.userType === "farmer" || data.userType === "buyer") {
                allUsers.push({
                    id: document.id,
                    name: data.name || data.username || "Not provided",
                    email: data.email || "Not provided",
                    userType: data.userType,
                    district: data.district || "Not provided",
                    contact: data.contact || data.companyContact || "Not provided"
                });
            }
        });

        displayUsers(allUsers);

    } catch (error) {
        console.error("User loading error:", error);
        usersTableBody.replaceChildren();

        usersMessage.textContent =
            "Unable to load users. Check Firebase permissions.";
    }
}

// DISPLAY USERS
function displayUsers(users) {

    usersTableBody.replaceChildren();

    if (users.length === 0) {
        const row = document.createElement("tr");
        const cell = document.createElement("td");

        cell.colSpan = 6;
        cell.textContent = "No users found.";

        row.appendChild(cell);
        usersTableBody.appendChild(row);

        usersMessage.textContent = "0 users found.";
        return;
    }

    users.forEach((user) => {

        const row = document.createElement("tr");

        const nameCell = document.createElement("td");
        nameCell.textContent = user.name;

        const emailCell = document.createElement("td");
        emailCell.textContent = user.email;

        const roleCell = document.createElement("td");
        const badge = document.createElement("span");

        badge.className = "role-badge " + user.userType;
        badge.textContent =
            user.userType.charAt(0).toUpperCase() +
            user.userType.slice(1);

        roleCell.appendChild(badge);

        const districtCell = document.createElement("td");
        districtCell.textContent = user.district;

        const contactCell = document.createElement("td");
        contactCell.textContent = user.contact;

        const actionCell = document.createElement("td");
        const deleteButton = document.createElement("button");

        deleteButton.textContent = "Delete";
        deleteButton.className = "delete-user-btn";

        deleteButton.addEventListener("click", () => {
            deleteUser(user.id, user.name);
        });

        actionCell.appendChild(deleteButton);

        row.append(
            nameCell,
            emailCell,
            roleCell,
            districtCell,
            contactCell,
            actionCell
        );

        usersTableBody.appendChild(row);
    });

    usersMessage.textContent = `Showing ${users.length} users.`;
}


// DELETE USER PROFILE
async function deleteUser(userId, userName) {

    const confirmed = confirm(
        "Are you sure you want to remove " + userName +
        "'s profile? This action cannot be undone."
    );

    if (!confirmed) {
        return;
    }

    try {
        await deleteDoc(doc(db, "users", userId));

        alert("User profile removed successfully.");

        await loadUsers();

    } catch (error) {
        console.error("User deletion error:", error);
        alert("Unable to remove user profile. Please try again.");
    }
}
// SEARCH AND FILTER
function filterUsers() {

    const searchValue = userSearch.value.toLowerCase().trim();
    const selectedType = userTypeFilter.value;

    const filteredUsers = allUsers.filter((user) => {

        const matchesSearch =
            user.name.toLowerCase().includes(searchValue) ||
            user.email.toLowerCase().includes(searchValue);

        const matchesType =
            selectedType === "all" ||
            user.userType === selectedType;

        return matchesSearch && matchesType;
    });

    displayUsers(filteredUsers);
}

userSearch.addEventListener("input", filterUsers);
userTypeFilter.addEventListener("change", filterUsers);

// LOGOUT
document.getElementById("logoutBtn").addEventListener("click", async () => {

    if (confirm("Are you sure you want to logout?")) {
        try {
            await signOut(auth);
            window.location.replace("login.html");
        } catch (error) {
            console.error("Logout error:", error);
            alert("Unable to logout. Please try again.");
        }
    }
});

// MOBILE SIDEBAR
const menuToggle = document.getElementById("menuToggle");
const adminSidebar = document.getElementById("adminSidebar");

menuToggle.addEventListener("click", () => {
    adminSidebar.classList.toggle("show");
});

document.querySelectorAll(".admin-nav .nav-item").forEach((link) => {
    link.addEventListener("click", () => {
        adminSidebar.classList.remove("show");
    });
});

// DARK MODE
const themeToggle = document.getElementById("themeToggle");

const savedTheme = localStorage.getItem("rubora-admin-theme");

if (savedTheme === "dark") {
    document.body.classList.add("dark-mode");
    themeToggle.innerHTML = '<i class="bi bi-sun"></i>';
}

themeToggle.addEventListener("click", () => {

    document.body.classList.toggle("dark-mode");

    const isDark = document.body.classList.contains("dark-mode");

    localStorage.setItem(
        "rubora-admin-theme",
        isDark ? "dark" : "light"
    );

    themeToggle.innerHTML = isDark
        ? '<i class="bi bi-sun"></i>'
        : '<i class="bi bi-moon-stars"></i>';
});



