
import { auth, db } from "./firebase-config.js";

import {
    collection,
    getDocs,
    query,
    orderBy
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

const requestsTableBody = document.getElementById("requestsTableBody");
const requestsMessage = document.getElementById("requestsMessage");

const requestSearch = document.getElementById("requestSearch");
const requestTypeFilter = document.getElementById("requestTypeFilter");
const requestStatusFilter = document.getElementById("requestStatusFilter");

let allRequests = [];

function formatPrice(value) {
    if (value === undefined || value === null || value === "") {
        return "N/A";
    }

    return "Rs. " + Number(value).toLocaleString("en-US");
}

function formatDate(timestamp) {
    if (!timestamp) return "N/A";

    const date = timestamp.toDate
        ? timestamp.toDate()
        : new Date(timestamp);

    if (Number.isNaN(date.getTime())) return "N/A";

    return date.toLocaleString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit"
    });
}

function getStatusClass(status) {
    const value = String(status || "").toLowerCase();

    if (value === "accepted") return "accepted";
    if (value === "rejected") return "rejected";
    if (value === "pending") return "";

    return "other";
}

function displayRequests(requests) {
    requestsTableBody.innerHTML = "";

    if (requests.length === 0) {
        requestsTableBody.innerHTML = `
            <tr>
                <td colspan="9" class="text-center">
                    No requests found.
                </td>
            </tr>
        `;
        return;
    }

    requests.forEach((request) => {
        const row = document.createElement("tr");

        const direction = request.type === "buyer"
            ? "Buyer to Farmer"
            : "Farmer to Buyer";

        const sender =
            request.senderName ||
            request.sender ||
            request.senderEmail ||
            "N/A";

        const receiver = request.type === "buyer"
            ? request.farmerName || request.farmerEmail || "Farmer"
            : request.buyer || request.recipientUID || "Buyer";

        const rubberType = request.rubberType || "N/A";
        const quantity = request.quantity ?? "N/A";
        const offeredPrice = formatPrice(request.offeredPrice);
        const message = request.message || "No message";
        const status = request.status || "Pending";
        const date = formatDate(request.createdAt);

        const values = [
            direction,
            sender,
            receiver,
            rubberType,
            quantity,
            offeredPrice,
            message,
            status,
            date
        ];

        values.forEach((value, index) => {
            const cell = document.createElement("td");

            if (index === 0) {
                const badge = document.createElement("span");
                badge.className = "request-direction";

                if (request.type === "farmer") {
                    badge.classList.add("farmer");
                }

                badge.textContent = value;
                cell.appendChild(badge);

            } else if (index === 7) {
                const badge = document.createElement("span");
                badge.className = "request-status " + getStatusClass(status);
                badge.textContent = value;
                cell.appendChild(badge);

            } else {
                cell.textContent = String(value);
            }

            row.appendChild(cell);
        });

        requestsTableBody.appendChild(row);
    });
}

function filterRequests() {
    const search = requestSearch.value.toLowerCase().trim();
    const selectedType = requestTypeFilter.value;
    const selectedStatus = requestStatusFilter.value.toLowerCase();

    const filtered = allRequests.filter((request) => {
        const sender = (
            request.senderName ||
            request.sender ||
            request.senderEmail ||
            ""
        ).toLowerCase();

        const receiver = (
            request.type === "buyer"
                ? request.farmerName || request.farmerEmail || ""
                : request.buyer || request.recipientUID || ""
        ).toLowerCase();

        const rubberType = (request.rubberType || "").toLowerCase();
        const message = (request.message || "").toLowerCase();

        const matchesSearch =
            sender.includes(search) ||
            receiver.includes(search) ||
            rubberType.includes(search) ||
            message.includes(search);

        const matchesType =
            !selectedType || request.type === selectedType;

        const matchesStatus =
            !selectedStatus ||
            String(request.status || "Pending").toLowerCase() === selectedStatus;

        return matchesSearch && matchesType && matchesStatus;
    });

    displayRequests(filtered);

    requestsMessage.textContent =
        `${filtered.length} request(s) found.`;
}

async function loadRequests() {
    requestsMessage.textContent = "Loading requests...";

    try {
        const [buyerSnapshot, farmerSnapshot] = await Promise.all([
            getDocs(query(
                collection(db, "buyerRequests"),
                orderBy("createdAt", "desc")
            )),
            getDocs(query(
                collection(db, "farmerRequests"),
                orderBy("createdAt", "desc")
            ))
        ]);

        const buyerRequests = buyerSnapshot.docs.map((item) => ({
            id: item.id,
            type: "buyer",
            ...item.data()
        }));

        const farmerRequests = farmerSnapshot.docs.map((item) => ({
            id: item.id,
            type: "farmer",
            ...item.data()
        }));

        allRequests = [...buyerRequests, ...farmerRequests];

        allRequests.sort((a, b) => {
            const dateA = a.createdAt?.toMillis
                ? a.createdAt.toMillis()
                : 0;

            const dateB = b.createdAt?.toMillis
                ? b.createdAt.toMillis()
                : 0;

            return dateB - dateA;
        });

        displayRequests(allRequests);

        requestsMessage.textContent =
            `${allRequests.length} total request(s) found.`;

    } catch (error) {
        console.error("Requests loading error:", error);

        requestsMessage.textContent =
            "Unable to load requests. Please check Firestore permissions.";
    }
}

requestSearch.addEventListener("input", filterRequests);
requestTypeFilter.addEventListener("change", filterRequests);
requestStatusFilter.addEventListener("change", filterRequests);

onAuthStateChanged(auth, async (user) => {
    if (!user) {
        window.location.href = "admin-login.html";
        return;
    }

    try {
        const tokenResult = await user.getIdTokenResult(true);

        if (tokenResult.claims.admin !== true) {
            alert("Access denied. Admins only.");
            window.location.href = "index.html";
            return;
        }

        await loadRequests();

    } catch (error) {
        console.error("Admin verification error:", error);
        requestsMessage.textContent = "Admin verification failed.";
    }
});

document.getElementById("logoutBtn").addEventListener("click", async () => {
    try {
        await signOut(auth);
        window.location.href = "admin-login.html";
    } catch (error) {
        console.error("Logout error:", error);
        alert("Unable to log out.");
    }
});

const adminSidebar = document.getElementById("adminSidebar");
const menuToggle = document.getElementById("menuToggle");

menuToggle?.addEventListener("click", () => {
    adminSidebar.classList.toggle("show");
});

const themeToggle = document.getElementById("themeToggle");

if (localStorage.getItem("rubora-admin-theme") === "dark") {
    document.body.classList.add("dark-mode");
}

themeToggle?.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");

    localStorage.setItem(
        "rubora-admin-theme",
        document.body.classList.contains("dark-mode") ? "dark" : "light"
    );
});
