
import { db, auth } from "./firebase-config.js";

import {
    collection,
    addDoc,
    serverTimestamp,
    getDocs,
    query,
    where,
    orderBy
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";


// HTML ELEMENTS

const buyerPriceForm = document.getElementById("buyerPriceForm");

const priceHistoryContainer = document.getElementById("priceHistoryContainer");

const mainSection = document.getElementById("buyerPriceMainSection");

const historySection = document.getElementById("priceHistorySection");

const historyButton = document.getElementById("myPriceHistoryBtn");

const backButton = document.getElementById("backToPublishBtn");


// HTML SAFE TEXT

function escapeHtml(value = "") {

    return String(value).replace(/[&<>"']/g, c => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    }[c]));

}


// SHOW PRICE HISTORY

if (historyButton) {

    historyButton.addEventListener("click", async () => {

        mainSection.hidden = true;
        historySection.hidden = false;

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });

        if (auth.currentUser) {
            await loadPriceHistory(auth.currentUser);
        }

    });

}


// BACK TO PUBLISH PRICE

if (backButton) {

    backButton.addEventListener("click", () => {

        historySection.hidden = true;
        mainSection.hidden = false;

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });

    });

}


// LOAD BUYER PRICE HISTORY

async function loadPriceHistory(user) {

    if (!priceHistoryContainer) return;

    priceHistoryContainer.innerHTML = `
        <div class="history-message">
            <i class="bi bi-clock-history"></i>
            <h5>Loading Price History...</h5>
            <p>Please wait while we load your published prices.</p>
        </div>
    `;

    try {

        const historyQuery = query(
            collection(db, "buyerPrices"),
            where("buyerUID", "==", user.uid),
            orderBy("createdAt", "desc")
        );

        const snapshot = await getDocs(historyQuery);


        if (snapshot.empty) {

            priceHistoryContainer.innerHTML = `
                <div class="history-message">

                    <i class="bi bi-inbox"></i>

                    <h5>No Published Prices Yet</h5>

                    <p>
                        Your published buying prices will appear here.
                    </p>

                </div>
            `;

            return;
        }


        priceHistoryContainer.innerHTML = snapshot.docs.map(item => {

            const data = item.data();

            const publishedDate = data.createdAt?.toDate
                ? data.createdAt.toDate().toLocaleString()
                : "Date unavailable";


            return `

                <div class="price-history-card">

                    <div class="price-card-top">

                        <h3 class="price-type">
                            ${escapeHtml(data.rubberType || "Rubber")}
                        </h3>

                        <span class="price-status">
                            Published
                        </span>

                    </div>


                    <h2 class="price-amount">
                        Rs. ${Number(data.price || 0).toLocaleString()}
                        <small style="font-size:15px;">/ Kg</small>
                    </h2>


                    <div class="price-details">

                        <div class="price-detail">

                            <small>
                                <i class="bi bi-buildings"></i>
                                Company
                            </small>

                            <strong>
                                ${escapeHtml(data.company || "Not specified")}
                            </strong>

                        </div>


                        <div class="price-detail">

                            <small>
                                <i class="bi bi-geo-alt"></i>
                                District
                            </small>

                            <strong>
                                ${escapeHtml(data.district || "Not specified")}
                            </strong>

                        </div>

                    </div>


                    ${data.details ? `

                        <p class="price-description">
                            ${escapeHtml(data.details)}
                        </p>

                    ` : ""}


                    <div class="price-date">

                        <i class="bi bi-calendar-check"></i>

                        Published: ${escapeHtml(publishedDate)}

                    </div>

                </div>

            `;

        }).join("");


    } catch (error) {

        console.error("History loading error:", error);

        priceHistoryContainer.innerHTML = `
            <div class="history-message">

                <i class="bi bi-exclamation-circle"></i>

                <h5>Unable to Load Price History</h5>

                <p>Please try again later.</p>

            </div>
        `;

    }

}


// CHECK LOGIN

onAuthStateChanged(auth, (user) => {

    if (user) {

        loadPriceHistory(user);

    } else if (priceHistoryContainer) {

        priceHistoryContainer.innerHTML = `
            <div class="history-message">

                <i class="bi bi-person-lock"></i>

                <h5>Please Login</h5>

                <p>Login to view your published price history.</p>

            </div>
        `;

    }

});


// PUBLISH BUYING PRICE

if (buyerPriceForm) {

    buyerPriceForm.addEventListener("submit", async (e) => {

        e.preventDefault();


        if (!auth.currentUser) {

            alert("Please login first.");
            return;

        }


        const company = document.getElementById("companyName").value.trim();

        const district = document.getElementById("district").value;

        const rubberType = document.getElementById("rubberType").value;

        const price = document.getElementById("buyingPrice").value;

        const details = document.getElementById("details").value.trim();


        if (
            !company ||
            !district ||
            !rubberType ||
            !price ||
            Number(price) <= 0
        ) {

            alert("Please fill all required fields correctly.");
            return;

        }


        const submitButton = buyerPriceForm.querySelector('button[type="submit"]');

        submitButton.disabled = true;

        submitButton.innerHTML = `
            <i class="bi bi-hourglass-split"></i>
            Publishing...
        `;


        try {

            await addDoc(
                collection(db, "buyerPrices"),
                {

                    company: company,

                    district: district,

                    rubberType: rubberType,

                    price: Number(price),

                    details: details,

                    buyerEmail: auth.currentUser.email || "",

                    buyerUID: auth.currentUser.uid,

                    createdAt: serverTimestamp()

                }
            );

            // Send notification to admin
try {
    await addDoc(collection(db, "notifications"), {
        userId: "1hlyOC1e9XYddTyPKLuu0plVlfL2",
        type: "price",
        title: "New Buying Price Published",
        message: `${company} published a buying price of Rs. ${Number(price).toLocaleString()} per kg for ${rubberType} rubber in ${district}.`,
        read: false,
        createdAt: serverTimestamp()
    });
} catch (notificationError) {
    console.error("Admin price notification error:", notificationError);
}


            alert("Buying price published successfully!");

            buyerPriceForm.reset();

            // Open My Price History section
            mainSection.hidden = true;
            historySection.hidden = false;

            // Load updated price history
            await loadPriceHistory(auth.currentUser);

            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });

        } catch (error) {

            console.error("Error publishing buying price:", error);

            alert("Error: " + error.message);


        } finally {

            submitButton.disabled = false;

            submitButton.innerHTML = `
                <i class="bi bi-cloud-arrow-up-fill"></i>
                Publish Buying Price
            `;

        }

    });

}
