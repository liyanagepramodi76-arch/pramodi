
import { auth } from "./firebase-config.js";

import {
    onAuthStateChanged,
    updateProfile,
    updatePassword,
    signOut
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

// HTML elements
const adminName = document.getElementById("adminName");
const adminEmail = document.getElementById("adminEmail");
const detailName = document.getElementById("detailName");
const detailEmail = document.getElementById("detailEmail");

const editBtn = document.getElementById("editBtn");
const passwordBtn = document.getElementById("passwordBtn");

const editSection = document.getElementById("editSection");
const passwordSection = document.getElementById("passwordSection");

const newName = document.getElementById("newName");
const newPassword = document.getElementById("newPassword");

let currentAdmin = null;

// Check admin login
onAuthStateChanged(auth, async (user) => {

    if (!user) {
        window.location.href = "login.html";
        return;
    }

    try {
        const tokenResult = await user.getIdTokenResult(true);

        if (tokenResult.claims.admin !== true) {
            alert("Access denied. Admin only.");
            await signOut(auth);
            window.location.href = "login.html";
            return;
        }

        currentAdmin = user;

        const name = user.displayName || "Administrator";
        const email = user.email || "Not available";

        adminName.textContent = name;
        adminEmail.textContent = email;

        detailName.textContent = name;
        detailEmail.textContent = email;

        newName.value = name;

    } catch (error) {
        console.error("Admin verification error:", error);
        alert("Unable to verify admin account.");
        await signOut(auth);
        window.location.href = "login.html";
    }
});


// Show edit profile section
editBtn.addEventListener("click", () => {
    passwordSection.style.display = "none";
    editSection.style.display =
        editSection.style.display === "block" ? "none" : "block";
});


// Cancel edit
document.getElementById("cancelEditBtn").addEventListener("click", () => {
    editSection.style.display = "none";
});


// Save admin name
document.getElementById("saveNameBtn").addEventListener("click", async () => {

    const name = newName.value.trim();

    if (!name) {
        alert("Please enter an admin name.");
        return;
    }

    try {
        await updateProfile(currentAdmin, {
            displayName: name
        });

        adminName.textContent = name;
        detailName.textContent = name;

        alert("Admin name updated successfully!");
        editSection.style.display = "none";

    } catch (error) {
        console.error(error);
        alert(error.message);
    }
});


// Show password section
passwordBtn.addEventListener("click", () => {
    editSection.style.display = "none";
    passwordSection.style.display =
        passwordSection.style.display === "block" ? "none" : "block";
});


// Cancel password change
document.getElementById("cancelPasswordBtn").addEventListener("click", () => {
    passwordSection.style.display = "none";
    newPassword.value = "";
});


// Update password
document.getElementById("savePasswordBtn").addEventListener("click", async () => {

    const password = newPassword.value;

    if (password.length < 6) {
        alert("Password must contain at least 6 characters.");
        return;
    }

    try {
        await updatePassword(currentAdmin, password);

        alert("Password changed successfully!");

        newPassword.value = "";
        passwordSection.style.display = "none";

    } catch (error) {
        console.error(error);

        if (error.code === "auth/requires-recent-login") {
            alert("For security, please log out and log in again before changing your password.");
        } else {
            alert(error.message);
        }
    }
});
