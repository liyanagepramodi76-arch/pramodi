
import { auth, db } from "./firebase-config.js";

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

import {
    collection,
    query,
    where,
    orderBy,
    onSnapshot,
    doc,
    updateDoc
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

const notificationList = document.getElementById("notificationList");
const notificationMessage = document.getElementById("notificationMessage");

let allNotifications = [];

onAuthStateChanged(auth, async (user) => {

    if (!user) {
        window.location.replace("login.html");
        return;
    }

    try {
        const token = await user.getIdTokenResult(true);

        if (token.claims.admin !== true) {
            alert("Admin access required.");
            await signOut(auth);
            window.location.replace("login.html");
            return;
        }

        loadNotifications(user.uid);

    } catch (error) {
        console.error(error);
        alert("Unable to verify admin access.");
        await signOut(auth);
        window.location.replace("login.html");
    }
});

function loadNotifications(adminUID) {

    const notificationQuery = query(
    collection(db, "notifications"),
    where("userId", "==", adminUID)
);

    onSnapshot(notificationQuery, (snapshot) => {

        allNotifications = snapshot.docs.map(item => ({
    id: item.id,
    ...item.data()
}));

allNotifications.sort((a, b) => {
    const dateA = a.createdAt?.toMillis?.() || 0;
    const dateB = b.createdAt?.toMillis?.() || 0;
    return dateB - dateA;
});

        updateSummary();
        displayNotifications();

        notificationMessage.textContent =
            allNotifications.length + " notifications found.";

    }, (error) => {

        console.error("Notification loading error:", error);

        notificationMessage.textContent =
            "Unable to load notifications. Check Firestore permissions.";

    });
}

function updateSummary() {

    const total = allNotifications.length;
    const unread = allNotifications.filter(item => item.read !== true).length;
    const read = total - unread;

    document.getElementById("totalNotifications").textContent = total;
    document.getElementById("unreadNotifications").textContent = unread;
    document.getElementById("readNotifications").textContent = read;
}

function displayNotifications() {

    notificationList.replaceChildren();

    const typeFilter = document.getElementById("notificationFilter").value;
    const statusFilter = document.getElementById("notificationStatus").value;

    const filtered = allNotifications.filter(item => {

        const typeMatch = typeFilter === "all" || item.type === typeFilter;

        const statusMatch =
            statusFilter === "all" ||
            (statusFilter === "read" && item.read === true) ||
            (statusFilter === "unread" && item.read !== true);

        return typeMatch && statusMatch;
    });

    if (filtered.length === 0) {
        notificationList.innerHTML =
            "<p>No notifications available.</p>";
        return;
    }

    filtered.forEach(item => {

        const card = document.createElement("div");
        card.className =
            "notification-item " +
            (item.read === true ? "read" : "unread");

        const icon = document.createElement("div");
        icon.className = "notification-icon";

        const iconElement = document.createElement("i");

        const icons = {
            registration: "bi-person-plus",
            stock: "bi-box-seam",
            price: "bi-tags",
            request: "bi-chat-square-text"
        };

        iconElement.className =
            "bi " + (icons[item.type] || "bi-bell");

        icon.appendChild(iconElement);

        const details = document.createElement("div");
        details.className = "notification-details";

        const heading = document.createElement("h5");
        heading.textContent = item.title || "New Activity";

        const description = document.createElement("p");
        description.textContent = item.message || "";

        const date = document.createElement("small");

        date.textContent = item.createdAt?.toDate
            ? item.createdAt.toDate().toLocaleString()
            : "Recently";

        details.append(heading, description, date);

        const actions = document.createElement("div");
        actions.className = "notification-actions";

        if (item.read !== true) {

            const button = document.createElement("button");
            button.type = "button";
            button.title = "Mark as read";

            const buttonIcon = document.createElement("i");
            buttonIcon.className = "bi bi-check2-circle";

            button.appendChild(buttonIcon);

            button.addEventListener("click", () => {
                markAsRead(item.id);
            });

            actions.appendChild(button);
        }

        card.append(icon, details, actions);
        notificationList.appendChild(card);
    });
}

async function markAsRead(notificationID) {

    try {
        await updateDoc(
            doc(db, "notifications", notificationID),
            { read: true }
        );
    } catch (error) {
        console.error("Update notification error:", error);
        alert("Unable to update notification.");
    }
}

document.getElementById("notificationFilter")
    .addEventListener("change", displayNotifications);

document.getElementById("notificationStatus")
    .addEventListener("change", displayNotifications);

document.getElementById("logoutBtn")
    .addEventListener("click", async () => {
        await signOut(auth);
        window.location.replace("login.html");
    });

document.getElementById("menuToggle")
    .addEventListener("click", () => {
        document.getElementById("adminSidebar")
            .classList.toggle("active");
    });

document.getElementById("themeToggle")
    .addEventListener("click", () => {
        document.body.classList.toggle("dark-mode");
    });
