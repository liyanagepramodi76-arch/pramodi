
import { auth, db } from "./firebase-config.js";

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

import {
    collection,
    getDocs,
    doc,
    deleteDoc
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

const stocksTableBody = document.getElementById("stocksTableBody");
const stockSearch = document.getElementById("stockSearch");
const stockStatusFilter = document.getElementById("stockStatusFilter");
const stocksMessage = document.getElementById("stocksMessage");

let allStocks = [];

// ADMIN SECURITY
onAuthStateChanged(auth, async (user) => {

    if (!user) {
        window.location.replace("login.html");
        return;
    }

    try {
        const tokenResult = await user.getIdTokenResult(true);

        if (tokenResult.claims.admin !== true) {
            alert("Access denied! Admin permission required.");
            await signOut(auth);
            window.location.replace("login.html");
            return;
        }

        await loadStocks();

    } catch (error) {
        console.error("Admin verification error:", error);
        alert("Unable to verify administrator access.");
        await signOut(auth);
        window.location.replace("login.html");
    }
});

// LOAD STOCKS
async function loadStocks() {

    stocksMessage.textContent = "Loading stocks...";

    try {
        const [stocksSnapshot, usersSnapshot] = await Promise.all([
            getDocs(collection(db, "publishedStocks")),
            getDocs(collection(db, "users"))
        ]);

        const usersMap = new Map();

        usersSnapshot.forEach((userDoc) => {
            usersMap.set(userDoc.id, userDoc.data());
        });

        allStocks = stocksSnapshot.docs.map((stockDoc) => {

            const stock = stockDoc.data();
            const farmer = usersMap.get(stock.farmerUID) || {};

            return {
                id: stockDoc.id,
                farmerName: stock.farmerName || farmer.name || "Not provided",
                district: farmer.district || "Not provided",
                rubberType: stock.rubberType || "Not provided",
                quantity: stock.quantity ?? "Not provided",
                price: stock.price ?? "Not provided",
                status: stock.status || "Available",
                createdAt: stock.createdAt?.seconds || 0
            };
        });

        allStocks.sort((a, b) => b.createdAt - a.createdAt);

        displayStocks(allStocks);

    } catch (error) {
        console.error("Stock loading error:", error);

        stocksTableBody.replaceChildren();

        stocksMessage.textContent =
            "Unable to load stocks. Check Firebase permissions.";
    }
}

// DISPLAY STOCKS
function displayStocks(stocks) {

    stocksTableBody.replaceChildren();

    if (stocks.length === 0) {

        const row = document.createElement("tr");
        const cell = document.createElement("td");

        cell.colSpan = 7;
        cell.textContent = "No rubber stocks found.";

        row.appendChild(cell);
        stocksTableBody.appendChild(row);

        stocksMessage.textContent = "0 stocks found.";
        return;
    }

    stocks.forEach((stock) => {

        const row = document.createElement("tr");

        const values = [
            stock.farmerName,
            stock.district,
            stock.rubberType,
            stock.quantity,
            stock.price === "Not provided"
                ? stock.price
                : `Rs. ${stock.price}`
        ];

        values.forEach((value) => {
            const cell = document.createElement("td");
            cell.textContent = value;
            row.appendChild(cell);
        });

        const statusCell = document.createElement("td");
        const statusBadge = document.createElement("span");

        statusBadge.textContent = stock.status;
        statusBadge.style.padding = "5px 10px";
        statusBadge.style.borderRadius = "20px";
        statusBadge.style.fontSize = "12px";
        statusBadge.style.background =
            stock.status.toLowerCase() === "available"
                ? "#dcfce7"
                : "#fee2e2";

        statusBadge.style.color =
            stock.status.toLowerCase() === "available"
                ? "#166534"
                : "#991b1b";

        statusCell.appendChild(statusBadge);
        row.appendChild(statusCell);

        const actionCell = document.createElement("td");
        const deleteButton = document.createElement("button");

        deleteButton.textContent = "Delete";
        deleteButton.className = "delete-user-btn";

        deleteButton.addEventListener("click", () => {
            deleteStock(stock.id, stock.rubberType);
        });

        actionCell.appendChild(deleteButton);
        row.appendChild(actionCell);

        stocksTableBody.appendChild(row);
    });

    stocksMessage.textContent = `Showing ${stocks.length} rubber stocks.`;
}


// DELETE STOCK
async function deleteStock(stockId, rubberType) {

    const confirmed = confirm(
        "Are you sure you want to delete this " + rubberType + " stock?"
    );

    if (!confirmed) {
        return;
    }

    try {
        await deleteDoc(doc(db, "publishedStocks", stockId));

        alert("Rubber stock deleted successfully.");

        await loadStocks();

    } catch (error) {
        console.error("Stock deletion error:", error);
        alert("Unable to delete this stock. Please try again.");
    }
}
// SEARCH AND FILTER
function filterStocks() {

    const searchValue = stockSearch.value.toLowerCase().trim();
    const selectedStatus = stockStatusFilter.value;

    const filteredStocks = allStocks.filter((stock) => {

        const matchesSearch =
            stock.farmerName.toLowerCase().includes(searchValue) ||
            stock.district.toLowerCase().includes(searchValue) ||
            stock.rubberType.toLowerCase().includes(searchValue);

        const matchesStatus =
            selectedStatus === "all" ||
            stock.status.toLowerCase() === selectedStatus;

        return matchesSearch && matchesStatus;
    });

    displayStocks(filteredStocks);
}

stockSearch.addEventListener("input", filterStocks);
stockStatusFilter.addEventListener("change", filterStocks);

// LOGOUT
document.getElementById("logoutBtn").addEventListener("click", async () => {

    if (confirm("Are you sure you want to logout?")) {

        try {
            await signOut(auth);
            window.location.replace("login.html");

        } catch (error) {
            console.error("Logout error:", error);
            alert("Unable to logout. Please try again.");
        }
    }
});

// MOBILE SIDEBAR
const menuToggle = document.getElementById("menuToggle");
const adminSidebar = document.getElementById("adminSidebar");

menuToggle.addEventListener("click", () => {
    adminSidebar.classList.toggle("show");
});

document.querySelectorAll(".admin-nav .nav-item").forEach((link) => {
    link.addEventListener("click", () => {
        adminSidebar.classList.remove("show");
    });
});

// DARK MODE
const themeToggle = document.getElementById("themeToggle");

const savedTheme = localStorage.getItem("rubora-admin-theme");

if (savedTheme === "dark") {
    document.body.classList.add("dark-mode");
    themeToggle.innerHTML = '<i class="bi bi-sun"></i>';
}

themeToggle.addEventListener("click", () => {

    document.body.classList.toggle("dark-mode");

    const isDark = document.body.classList.contains("dark-mode");

    localStorage.setItem(
        "rubora-admin-theme",
        isDark ? "dark" : "light"
    );

    themeToggle.innerHTML = isDark
        ? '<i class="bi bi-sun"></i>'
        : '<i class="bi bi-moon-stars"></i>';
});



