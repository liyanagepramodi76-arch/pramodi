
import { auth, db } from "./firebase-config.js";

import { onAuthStateChanged } from
    "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

import {
    collection,
    query,
    where,
    onSnapshot
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

const badge = document.getElementById("notificationCount");

if (badge) {
    onAuthStateChanged(auth, (user) => {
        if (!user) {
            badge.style.display = "none";
            return;
        }

        const unreadQuery = query(
            collection(db, "notifications"),
            where("userId", "==", user.uid),
            where("read", "==", false)
        );

        onSnapshot(unreadQuery, (snapshot) => {
            const count = snapshot.size;

            badge.textContent = count > 99 ? "99+" : String(count);
            badge.style.display = count > 0 ? "flex" : "none";
        }, (error) => {
            console.error("Unread notification count error:", error);
            badge.style.display = "none";
        });
    });
}
