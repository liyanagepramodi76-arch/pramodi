
import { auth, db } from "./firebase-config.js";

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

import {
    collection,
    getDocs,
    query,
    where,
    onSnapshot
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

// ================= ADMIN SECURITY =================

onAuthStateChanged(auth, async (user) => {

    if (!user) {
        window.location.replace("login.html");
        return;
    }

    try {

        const tokenResult = await user.getIdTokenResult(true);

        if (tokenResult.claims.admin !== true) {

            alert("Access denied! Admin permission required.");

            await signOut(auth);

            window.location.replace("login.html");

            return;
        }

        console.log("Admin verified:", user.email);

        loadDashboardData();
        loadRecentActivity(user.uid);

    } catch (error) {

        console.error("Admin verification failed:", error);

        await signOut(auth);

        window.location.replace("login.html");

    }

});


// ================= LOAD DASHBOARD DATA =================

async function loadDashboardData() {

    try {

        const usersSnapshot = await getDocs(collection(db, "users"));

        let farmers = 0;
        let buyers = 0;

        usersSnapshot.forEach((document) => {

            const userData = document.data();

            if (userData.userType === "farmer") {
                farmers++;
            }

            else if (userData.userType === "buyer") {
                buyers++;
            }

        });

        document.getElementById("totalFarmers").textContent = farmers;
        document.getElementById("totalBuyers").textContent = buyers;


        // Published stocks
        try {

            const stocksSnapshot = await getDocs(
                collection(db, "publishedStocks")
            );

            document.getElementById("totalStocks").textContent =
                stocksSnapshot.size;

        } catch (error) {

            console.error("Stock loading error:", error);
            document.getElementById("totalStocks").textContent = "N/A";

        }


        // Buyer prices
        try {

            const pricesSnapshot = await getDocs(
                collection(db, "buyerPrices")
            );

            document.getElementById("totalPrices").textContent =
                pricesSnapshot.size;

        } catch (error) {

            console.error("Price loading error:", error);
            document.getElementById("totalPrices").textContent = "N/A";

        }

        

// Total requests (Buyer + Farmer)
        try {

            const buyerRequestsSnapshot = await getDocs(
                collection(db, "buyerRequests")
            );

            const farmerRequestsSnapshot = await getDocs(
                collection(db, "farmerRequests")
            );

            const totalRequests =
                buyerRequestsSnapshot.size + farmerRequestsSnapshot.size;

            document.getElementById("totalRequests").textContent =
                totalRequests;

        } catch (error) {

            console.error("Request loading error:", error);
            document.getElementById("totalRequests").textContent = "N/A";

        }
console.log("Dashboard data loaded successfully.");

    } catch (error) {

        console.error("Dashboard loading error:", error);

        alert("Unable to load dashboard data. Please check Firebase permissions.");

    }

}

// ================= RECENT ACTIVITY =================

function loadRecentActivity(adminUID) {

    const activityList = document.getElementById("recentActivityList");

    const activityQuery = query(
        collection(db, "notifications"),
        where("userId", "==", adminUID)
    );

    onSnapshot(activityQuery, (snapshot) => {

        const activities = snapshot.docs.map((item) => ({
            id: item.id,
            ...item.data()
        }));

        activities.sort((a, b) => {
            const dateA = a.createdAt?.toMillis?.() || 0;
            const dateB = b.createdAt?.toMillis?.() || 0;
            return dateB - dateA;
        });

        // Update unread notification count
const unreadCount = activities.filter(
    activity => activity.read === false
).length;

const notificationBadge = document.getElementById(
    "unreadNotificationCount"
);

if (notificationBadge) {
    notificationBadge.textContent =
        unreadCount > 99 ? "99+" : unreadCount;

    notificationBadge.style.display =
        unreadCount > 0 ? "flex" : "none";
}

        activityList.replaceChildren();

        if (activities.length === 0) {
            activityList.innerHTML = `
                <div class="activity-empty">
                    <i class="bi bi-clipboard-data"></i>
                    <h4>No Recent Activity</h4>
                    <p>New registrations and marketplace updates will appear here.</p>
                </div>
            `;
            return;
        }

        activities.slice(0, 5).forEach((activity) => {

            const item = document.createElement("div");
            item.className = "activity-item";

            const icons = {
                registration: "bi-person-plus",
                stock: "bi-box-seam",
                price: "bi-tags",
                request: "bi-chat-square-text"
            };

            const icon = document.createElement("i");
            icon.className = `bi ${icons[activity.type] || "bi-bell"}`;

            const details = document.createElement("div");
            details.className = "activity-details";

            const title = document.createElement("h5");
            title.textContent = activity.title || "New Activity";

            const message = document.createElement("p");
            message.textContent = activity.message || "";

            const date = document.createElement("small");
            date.textContent = activity.createdAt?.toDate
                ? activity.createdAt.toDate().toLocaleString()
                : "Recently";

            details.append(title, message, date);
            item.append(icon, details);

            activityList.appendChild(item);

        });

    }, (error) => {

        console.error("Recent activity loading error:", error);

        activityList.textContent = "Unable to load recent activities.";

    });

}


// ================= LOGOUT =================

const logoutBtn = document.getElementById("logoutBtn");

logoutBtn.addEventListener("click", async () => {

    const confirmLogout = confirm("Are you sure you want to logout?");

    if (confirmLogout) {

        try {

            await signOut(auth);

            window.location.replace("login.html");

        } catch (error) {

            console.error("Logout error:", error);

            alert("Unable to logout. Please try again.");

        }

    }

});


// ================= MOBILE SIDEBAR =================

const menuToggle = document.getElementById("menuToggle");

const adminSidebar = document.getElementById("adminSidebar");

menuToggle.addEventListener("click", () => {

    adminSidebar.classList.toggle("show");

});


// Close sidebar after clicking a menu link

document.querySelectorAll(".admin-nav .nav-item").forEach((link) => {

    link.addEventListener("click", () => {

        adminSidebar.classList.remove("show");

    });

});


// ================= DARK MODE =================

const themeToggle = document.getElementById("themeToggle");

const savedTheme = localStorage.getItem("rubora-admin-theme");

if (savedTheme === "dark") {

    document.body.classList.add("dark-mode");

    themeToggle.innerHTML = '<i class="bi bi-sun"></i>';

}

themeToggle.addEventListener("click", () => {

    document.body.classList.toggle("dark-mode");

    const isDark = document.body.classList.contains("dark-mode");

    localStorage.setItem(
        "rubora-admin-theme",
        isDark ? "dark" : "light"
    );

    themeToggle.innerHTML = isDark
        ? '<i class="bi bi-sun"></i>'
        : '<i class="bi bi-moon-stars"></i>';

});

