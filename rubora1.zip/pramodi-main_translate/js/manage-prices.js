
import { auth, db } from "./firebase-config.js";

import {
    collection,
    getDocs,
    query,
    orderBy,
    doc,
    deleteDoc
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

const pricesTableBody = document.getElementById("pricesTableBody");
const pricesMessage = document.getElementById("pricesMessage");
const priceSearch = document.getElementById("priceSearch");
const districtFilter = document.getElementById("districtFilter");

let allPrices = [];

function showMessage(message) {
    pricesMessage.textContent = message;
}

function formatPrice(price) {
    return "Rs. " + Number(price || 0).toLocaleString("en-US");
}

function displayPrices(prices) {
    pricesTableBody.innerHTML = "";

    if (prices.length === 0) {
        pricesTableBody.innerHTML = `
            <tr>
                <td colspan="6" class="text-center">
                    No buyer prices found.
                </td>
            </tr>
        `;
        return;
    }

    prices.forEach((price) => {
        const row = document.createElement("tr");

        const values = [
            price.company || "N/A",
            price.district || "N/A",
            price.rubberType || "N/A",
            formatPrice(price.price),
            price.details || "No details"
        ];

        values.forEach((value) => {
            const cell = document.createElement("td");
            cell.textContent = value;
            row.appendChild(cell);
        });

        const actionCell = document.createElement("td");
        const deleteButton = document.createElement("button");

        deleteButton.textContent = "Delete";
        deleteButton.className = "delete-user-btn";

        deleteButton.addEventListener("click", () => {
            deletePrice(price.id, price.company);
        });

        actionCell.appendChild(deleteButton);
        row.appendChild(actionCell);

        pricesTableBody.appendChild(row);
    });
}


// DELETE BUYER PRICE
async function deletePrice(priceId, companyName) {

    const confirmed = confirm(
        "Are you sure you want to delete the price record from " +
        companyName + "?"
    );

    if (!confirmed) return;

    try {
        await deleteDoc(doc(db, "buyerPrices", priceId));

        alert("Buyer price record deleted successfully.");

        await loadPrices();

    } catch (error) {
        console.error("Buyer price deletion error:", error);
        alert("Unable to delete this price record. Please try again.");
    }
}
function populateDistricts(prices) {
    const districts = [
        ...new Set(
            prices
                .map(price => price.district)
                .filter(Boolean)
        )
    ].sort();

    districtFilter.innerHTML =
        '<option value="">All Districts</option>';

    districts.forEach((district) => {
        const option = document.createElement("option");
        option.value = district;
        option.textContent = district;
        districtFilter.appendChild(option);
    });
}

function filterPrices() {
    const searchValue = priceSearch.value.toLowerCase().trim();
    const selectedDistrict = districtFilter.value;

    const filteredPrices = allPrices.filter((price) => {
        const company = (price.company || "").toLowerCase();
        const district = (price.district || "").toLowerCase();
        const rubberType = (price.rubberType || "").toLowerCase();

        const matchesSearch =
            company.includes(searchValue) ||
            district.includes(searchValue) ||
            rubberType.includes(searchValue);

        const matchesDistrict =
            !selectedDistrict || price.district === selectedDistrict;

        return matchesSearch && matchesDistrict;
    });

    displayPrices(filteredPrices);
}

async function loadPrices() {
    showMessage("Loading buyer prices...");

    try {
        const pricesQuery = query(
            collection(db, "buyerPrices"),
            orderBy("createdAt", "desc")
        );

        const snapshot = await getDocs(pricesQuery);

        allPrices = snapshot.docs.map((document) => ({
            id: document.id,
            ...document.data()
        }));

        populateDistricts(allPrices);
        displayPrices(allPrices);

        showMessage(
            allPrices.length + " buyer price records found."
        );

    } catch (error) {
        console.error("Buyer prices loading error:", error);
        showMessage("Unable to load buyer prices. Please check permissions.");
    }
}

priceSearch.addEventListener("input", filterPrices);
districtFilter.addEventListener("change", filterPrices);

onAuthStateChanged(auth, async (user) => {
    if (!user) {
        window.location.href = "admin-login.html";
        return;
    }

    try {
        const tokenResult = await user.getIdTokenResult(true);

        if (tokenResult.claims.admin !== true) {
            alert("Access denied. Admins only.");
            window.location.href = "index.html";
            return;
        }

        await loadPrices();

    } catch (error) {
        console.error("Admin verification error:", error);
        showMessage("Admin verification failed.");
    }
});

document.getElementById("logoutBtn").addEventListener("click", async () => {
    try {
        await signOut(auth);
        window.location.href = "admin-login.html";
    } catch (error) {
        console.error("Logout error:", error);
        alert("Unable to log out.");
    }
});

const adminSidebar = document.getElementById("adminSidebar");
const menuToggle = document.getElementById("menuToggle");

menuToggle?.addEventListener("click", () => {
    adminSidebar.classList.toggle("show");
});

const themeToggle = document.getElementById("themeToggle");

if (localStorage.getItem("rubora-admin-theme") === "dark") {
    document.body.classList.add("dark-mode");
}

themeToggle?.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");

    localStorage.setItem(
        "rubora-admin-theme",
        document.body.classList.contains("dark-mode") ? "dark" : "light"
    );
});


