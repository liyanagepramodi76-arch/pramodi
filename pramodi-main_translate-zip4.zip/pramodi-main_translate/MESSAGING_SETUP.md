# Rubora two-way messaging setup

## What this update connects

- Farmers can click **Message Buyer** on a buyer's published buying-price card.
- Buyers can click **Message Farmer** on a farmer's published stock card.
- Both users see the same conversation in their Messages page. Replies appear automatically and messages are saved in Firestore.
- The system uses Firebase Authentication UIDs. Users do not need to know or enter each other's email addresses.
- Farmer stock publishing now saves to the `publishedStocks` collection, and the stock comparison page loads those Firestore listings instead of the old sample cards.

## Firestore collections

- `users/{uid}`: existing private user profile.
- `publicProfiles/{uid}`: minimum public chat/listing card (UID, display name, role, company name, and district only). Do not add NIC, home address, phone number, or email.
- `publishedStocks/{stockId}`: stock details and `farmerUID`.
- `buyerPrices/{priceId}`: buying-price details and `buyerUID` (already saved by the existing buyer-price form).
- `conversations/{uidA__uidB}`: one shared conversation document for both users.
- `conversations/{uidA__uidB}/messages/{messageId}`: saved messages.

## Firebase setup (required)

1. Open Firebase Console for project `rubbertrade-93755`.
2. Open **Firestore Database → Rules**.
3. Merge the match blocks from `firestore-chat-rules.txt` into your existing rules. Do not replace the entire rules file; preserve the rules for your other collections.
4. Make sure the existing rules allow the signed-in user to read their own `users/{uid}` document and create their own `publishedStocks` / `buyerPrices` documents.
5. Publish the rules.

The supplied chat rules restrict conversations and messages to the two participant UIDs. The public chat directory is readable only by authenticated users and stores display details only.

## Existing test accounts

New registrations create their public chat profile automatically. For accounts created before this update, sign in to each account and open **Messages** once. This creates or refreshes that account's public chat profile. The accounts must exist in Firebase Authentication, not only in a Firestore collection. The email address does not need to be real for ordinary Firebase email/password testing unless you have enabled email verification.

## Test both directions

1. Run the website using VS Code Live Server or another local web server. Do not open pages with `file://`.
2. Sign in as a farmer and publish a test stock listing.
3. Sign in as a buyer in a separate browser or incognito window. Open **Compare Farmer Stock** and click **Message Farmer**.
4. Send a message. The farmer should see the conversation in **Messages** and can reply.
5. Sign in as the farmer and open **Compare Buyer Prices**. Click **Message Buyer** on a buyer's price card.
6. Confirm both sides see the same conversation and that old messages remain after refreshing.

## Notes

- This update does not process payments or transactions.
- Live message delivery depends on the Firebase project being enabled and the Firestore rules being published. I cannot verify delivery to your live Firebase project from this ZIP alone.
- Old sample farmer cards have been replaced by actual `publishedStocks` records. Re-publish any sample stock you want to use for testing.
