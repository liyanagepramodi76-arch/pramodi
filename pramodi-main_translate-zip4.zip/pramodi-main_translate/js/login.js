
import { auth, db } from "./firebase-config.js";

import {
    signInWithEmailAndPassword
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

import {
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


// ================= PASSWORD SHOW / HIDE =================

const togglePassword = document.getElementById("togglePassword");
const password = document.getElementById("password");

if (togglePassword && password) {

    togglePassword.addEventListener("click", function () {

        if (password.type === "password") {

            password.type = "text";

            togglePassword.classList.remove("fa-eye");
            togglePassword.classList.add("fa-eye-slash");

        } else {

            password.type = "password";

            togglePassword.classList.remove("fa-eye-slash");
            togglePassword.classList.add("fa-eye");

        }

    });

}


// ================= FIREBASE LOGIN =================

const loginForm = document.querySelector("form");
const loginButton = document.querySelector(".login-btn");


loginForm.addEventListener("submit", async function (e) {

    e.preventDefault();

    const email = document.getElementById("email").value.trim();
    const userPassword = password.value;

    loginButton.classList.add("loading");
    loginButton.innerHTML = "Signing in...";
    loginButton.disabled = true;

    try {

        // Sign in user
        const userCredential = await signInWithEmailAndPassword(
            auth,
            email,
            userPassword
        );

        const user = userCredential.user;

        console.log("Logged in:", user.uid);


        // ================= ADMIN CHECK =================

        // Refresh Firebase ID token to get latest custom claims
        const tokenResult = await user.getIdTokenResult(true);

        if (tokenResult.claims.admin === true) {

            console.log("Admin login successful");

            window.location.href = "admin-dashboard.html";

            return;
        }


        // ================= FARMER / BUYER CHECK =================

        const userDoc = await getDoc(
            doc(db, "users", user.uid)
        );

        if (userDoc.exists()) {

            const userData = userDoc.data();

            console.log("User Type:", userData.userType);


            if (userData.userType === "farmer") {

                window.location.href = "farmer-profile.html";

            }

            else if (userData.userType === "buyer") {

                window.location.href = "buyer-profile.html";

            }

            else {

                alert("Invalid user role.");

                await auth.signOut();

            }

        }

        else {

            alert("User profile data not found.");

            await auth.signOut();

        }

    }

    catch (error) {

        console.log("Login Error:", error.code, error.message);

        if (error.code === "auth/user-not-found" ||
            error.code === "auth/invalid-credential") {

            alert("No account found or incorrect email/password.");

        }

        else if (error.code === "auth/wrong-password") {

            alert("Incorrect password.");

        }

        else if (error.code === "auth/invalid-email") {

            alert("Invalid email address.");

        }

        else {

            alert(error.message);

        }

    }

    finally {

        loginButton.classList.remove("loading");
        loginButton.innerHTML = "Sign In";
        loginButton.disabled = false;

    }

});
