
import { db, auth } from "./firebase-config.js";

import {
    collection,
    addDoc,
    serverTimestamp,
    doc,
    getDoc,
    getDocs,
    query,
    where
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

// HTML elements
const form = document.getElementById("publishStockForm");
const historyButton = document.getElementById("myStockHistoryBtn");
const backButton = document.getElementById("backToPublishBtn");

const publishSection = document.querySelector(".main-section");
const historySection = document.getElementById("stockHistorySection");
const historyContainer = document.getElementById("stockHistoryContainer");

let signedInUser = null;

// Wait until Firebase checks the login
onAuthStateChanged(auth, (user) => {
    signedInUser = user;
});


// -------------------------------------
// SHOW PUBLISH FORM
// -------------------------------------

function showPublishSection() {
    publishSection.hidden = false;
    historySection.hidden = true;
}


// -------------------------------------
// SHOW STOCK HISTORY
// -------------------------------------

async function showHistorySection() {

    if (!signedInUser) {
        alert("Please log in first.");
        window.location.href = "login.html";
        return;
    }

    publishSection.hidden = true;
    historySection.hidden = false;

    historyContainer.innerHTML = `
        <div class="history-message">
            <i class="bi bi-hourglass-split"></i>
            Loading your stock history...
        </div>
    `;

    await loadStockHistory();
}


// -------------------------------------
// LOAD FARMER'S STOCKS FROM FIREBASE
// -------------------------------------

async function loadStockHistory() {

    try {

        const stocksQuery = query(
            collection(db, "publishedStocks"),
            where("farmerUID", "==", signedInUser.uid)
        );

        const snapshot = await getDocs(stocksQuery);

        if (snapshot.empty) {

            historyContainer.innerHTML = `
                <div class="history-message" style="grid-column: 1 / -1;">
                    <i class="bi bi-box-seam"></i>
                    <h5>No Published Stocks Yet</h5>
                    <p>You have not published any rubber stocks yet.</p>
                </div>
            `;

            return;
        }

        // Convert Firebase documents into an array
        const stocks = [];

        snapshot.forEach((document) => {

            stocks.push({
                id: document.id,
                ...document.data()
            });

        });

        // Show newest published stock first
        stocks.sort((a, b) => {

            const dateA = a.createdAt?.toMillis
                ? a.createdAt.toMillis()
                : 0;

            const dateB = b.createdAt?.toMillis
                ? b.createdAt.toMillis()
                : 0;

            return dateB - dateA;

        });

        displayStockCards(stocks);

    } catch (error) {

        console.error("Error loading stock history:", error);

        historyContainer.innerHTML = `
            <div class="history-message" style="grid-column: 1 / -1;">
                <i class="bi bi-exclamation-circle"></i>
                <h5>Could Not Load Stock History</h5>
                <p>${escapeHTML(error.message)}</p>
            </div>
        `;

    }
}


// -------------------------------------
// DISPLAY STOCK CARDS
// -------------------------------------

function displayStockCards(stocks) {

    historyContainer.innerHTML = "";

    stocks.forEach((stock) => {

        const card = document.createElement("div");

        card.className = "stock-history-card";

        const harvestDate = stock.harvestDate || "Not provided";

        const publishedDate = stock.createdAt?.toDate
            ? stock.createdAt.toDate().toLocaleDateString()
            : "Recently published";

        const description = stock.description
            ? escapeHTML(stock.description)
            : "No additional description provided.";

        const status = stock.status || "Available";

        card.innerHTML = `

            <div class="stock-card-top">

                <div class="stock-type">
                    ${escapeHTML(stock.rubberType || "Rubber Stock")}
                </div>

                <span class="stock-status">
                    ${escapeHTML(status)}
                </span>

            </div>


            <div class="stock-details">

                <div class="stock-detail">
                    <small>
                        <i class="bi bi-box-seam"></i>
                        Quantity
                    </small>

                    <strong>
                        ${Number(stock.quantity || 0).toLocaleString()} Kg
                    </strong>
                </div>


                <div class="stock-detail">
                    <small>
                        <i class="bi bi-currency-rupee"></i>
                        Price per Kg
                    </small>

                    <strong>
                        Rs. ${Number(stock.price || 0).toLocaleString()}
                    </strong>
                </div>


                <div class="stock-detail">
                    <small>
                        <i class="bi bi-calendar-event"></i>
                        Harvest Date
                    </small>

                    <strong>
                        ${escapeHTML(harvestDate)}
                    </strong>
                </div>


                <div class="stock-detail">
                    <small>
                        <i class="bi bi-calendar-check"></i>
                        Published Date
                    </small>

                    <strong>
                        ${escapeHTML(publishedDate)}
                    </strong>
                </div>

            </div>


            <p class="stock-description">
                ${description}
            </p>

            <div class="stock-date">
                <i class="bi bi-check-circle-fill"></i>
                Published successfully
            </div>

        `;

        historyContainer.appendChild(card);

    });

}


// -------------------------------------
// ESCAPE HTML CONTENT
// -------------------------------------

function escapeHTML(value) {

    return String(value).replace(/[&<>"']/g, (character) => {

        const characters = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        };

        return characters[character];

    });

}


// -------------------------------------
// HISTORY BUTTON
// -------------------------------------

historyButton?.addEventListener("click", () => {

    if (historySection.hidden) {
        showHistorySection();
    } else {
        showPublishSection();
    }

});


// -------------------------------------
// BACK TO PUBLISH BUTTON
// -------------------------------------

backButton?.addEventListener("click", () => {

    showPublishSection();

});


// -------------------------------------
// PUBLISH STOCK
// -------------------------------------

form?.addEventListener("submit", async (event) => {

    event.preventDefault();

    if (!signedInUser) {
        alert("Please log in first.");
        window.location.href = "login.html";
        return;
    }

    const rubberType = document.getElementById("rubberType").value;
    const quantity = Number(document.getElementById("quantity").value);
    const price = Number(document.getElementById("price").value);
    const harvestDate = document.getElementById("harvestDate").value;
    const description = document.getElementById("description").value.trim();

    if (
        !rubberType ||
        !quantity ||
        quantity <= 0 ||
        !price ||
        price <= 0 ||
        !harvestDate
    ) {

        alert("Please enter a rubber type, valid quantity, price and harvest date.");
        return;

    }

    const button = form.querySelector("button[type='submit']");

    if (button) {
        button.disabled = true;
        button.innerHTML = `
            <i class="bi bi-hourglass-split"></i>
            Publishing...
        `;
    }

    try {

        // Get farmer details from users collection
        const farmerDoc = await getDoc(
            doc(db, "users", signedInUser.uid)
        );

        const farmerData = farmerDoc.exists()
            ? farmerDoc.data()
            : {};

        const farmerName =
            farmerData.name ||
            signedInUser.displayName ||
            "Farmer";

        const farmerEmail =
            farmerData.email ||
            signedInUser.email ||
            "";


        // Save stock in Firebase
        await addDoc(collection(db, "publishedStocks"), {

            farmerUID: signedInUser.uid,
            farmerName: farmerName,
            farmerEmail: farmerEmail,

            rubberType: rubberType,
            quantity: quantity,
            price: price,
            harvestDate: harvestDate,
            description: description,

            createdAt: serverTimestamp(),
            status: "Available"

        });


        alert("Stock published successfully!");

        // Clear the form
        form.reset();

        // Automatically open stock history
        await showHistorySection();


    } catch (error) {

        console.error("Error publishing stock:", error);

        alert("Could not publish stock: " + error.message);

    } finally {

        if (button) {
            button.disabled = false;
            button.innerHTML = `
                <i class="bi bi-cloud-arrow-up-fill"></i>
                Publish My Stock
            `;
        }

    }

});
