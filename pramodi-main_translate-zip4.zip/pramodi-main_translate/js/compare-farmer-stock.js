
import { auth, db } from "./firebase-config.js";

import {
  collection,
  getDocs,
  doc,
  getDoc,
  query,
  orderBy,
  addDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

const grid = document.getElementById("priceGrid");
const noResults = document.getElementById("noResults");

const escapeHtml = (value = "") => String(value).replace(/[&<>"']/g, c => ({
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}[c]));

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    grid.innerHTML = '<div class="price-card" style="grid-column:1/-1;text-align:center;padding:30px;">Please log in to view farmer stock. <a href="login.html">Login</a></div>';
    return;
  }

  try {
    const stockQuery = query(
      collection(db, "publishedStocks"),
      orderBy("createdAt", "desc")
    );

    const snapshot = await getDocs(stockQuery);

    const stocks = await Promise.all(snapshot.docs.map(async (item) => {
      const stock = item.data();
      let farmer = {};

      if (stock.farmerUID) {
        const userSnap = await getDoc(
          doc(db, "publicProfiles", stock.farmerUID)
        );

        if (userSnap.exists()) {
          farmer = userSnap.data();
        }
      }

      return {
        id: item.id,
        ...stock,
        farmerName: farmer.name || farmer.username || "Rubber Farmer",
        district: farmer.district || "Sri Lanka"
      };
    }));

    renderStocks(stocks);

  } catch (error) {
    console.error("Unable to load farmer stock:", error);

    grid.innerHTML = '<div class="price-card" style="grid-column:1/-1;text-align:center;padding:30px;">Unable to load stock. Please check your Firestore rules and try again.</div>';
  }
});

function renderStocks(items) {
  if (!items.length) {
    grid.innerHTML = '<div class="price-card" style="grid-column:1/-1;text-align:center;padding:30px;">No farmer stock has been published yet.</div>';

    if (noResults) noResults.style.display = "none";
    return;
  }

  grid.innerHTML = items.map(stock => `
    <article class="price-card"
      data-price="${Number(stock.price) || 0}"
      data-type="${escapeHtml(stock.rubberType || "")}"
      data-location="${escapeHtml(stock.district || "")}">

      <div class="user-info">
        <div class="user-icon">👨‍🌾</div>
        <div>
          <h3>${escapeHtml(stock.farmerName)}</h3>
          <p>📍 ${escapeHtml(stock.district)}</p>
        </div>
      </div>

      <div class="details">
        <div class="detail-row">
          <span>Rubber Type</span>
          <strong>${escapeHtml(stock.rubberType || "Not specified")}</strong>
        </div>

        <div class="detail-row">
          <span>Available Quantity</span>
          <strong>${Number(stock.quantity || 0).toLocaleString()} kg</strong>
        </div>

        <div class="detail-row">
          <span>Price</span>
          <strong class="price">Rs. ${Number(stock.price || 0).toLocaleString()}/kg</strong>
        </div>

        ${stock.harvestDate ? `
          <div class="detail-row">
            <span>Harvest Date</span>
            <strong>${escapeHtml(stock.harvestDate)}</strong>
          </div>
        ` : ""}

        ${stock.description ? `<p>${escapeHtml(stock.description)}</p>` : ""}
      </div>

      <button class="compare-btn"
          onclick="openFarmerRequest(
              decodeURIComponent('${encodeURIComponent(stock.farmerUID || "")}'),
              decodeURIComponent('${encodeURIComponent(stock.farmerName)}'),
              decodeURIComponent('${encodeURIComponent(stock.rubberType || "")}'),
              decodeURIComponent('${encodeURIComponent(stock.farmerEmail || "")}')
          )">
          <i class="bi bi-send"></i> Send Request
      </button>

      <a class="compare-btn"
        style="display:block;text-align:center;text-decoration:none;margin-top:10px;background:#166534;"
        href="chat.html?to=${encodeURIComponent(stock.farmerUID || "")}">
        <i class="bi bi-chat-dots"></i> Message Farmer
      </a>

    </article>
  `).join("");

  if (noResults) noResults.style.display = "none";

  if (typeof searchPrices === "function") searchPrices();
}

let selectedFarmer = {};

window.openFarmerRequest = function(uid, name, type, email) {
    if (!auth.currentUser) {
        alert("Please log in first.");
        return;
    }

    selectedFarmer = {
        uid: uid,
        name: name,
        type: type,
        email: email
    };

    document.getElementById("requestFarmerName").textContent = name;
    document.getElementById("requestQuantity").value = "";
    document.getElementById("requestPrice").value = "";
    document.getElementById("requestMessage").value = "";
    document.getElementById("requestFeedback").textContent = "";

    document.getElementById("requestModal").style.display = "flex";
};

window.closeRequest = function() {
    document.getElementById("requestModal").style.display = "none";
};

window.submitFarmerRequest = async function() {
    const quantity = Number(document.getElementById("requestQuantity").value);
    const price = Number(document.getElementById("requestPrice").value);
    const message = document.getElementById("requestMessage").value.trim();
    const feedback = document.getElementById("requestFeedback");
    const sendButton = document.getElementById("sendRequestBtn");

    if (!quantity || quantity <= 0 || !price || price <= 0) {
        feedback.textContent = "Please enter a valid quantity and price.";
        return;
    }

    if (!selectedFarmer.uid) {
        feedback.textContent = "Farmer information is missing.";
        return;
    }

    sendButton.disabled = true;
    sendButton.textContent = "Sending...";

    try {
          const buyerSnap = await getDoc(
              doc(db, "users", auth.currentUser.uid)
          );

          const buyerData = buyerSnap.exists() ? buyerSnap.data() : {};

          const buyerName =
              buyerData.personName ||
              buyerData.name ||
              buyerData.username ||
              "Buyer";

          await addDoc(collection(db, "buyerRequests"), {
              senderUID: auth.currentUser.uid,
              senderName: buyerName,
              senderEmail: auth.currentUser.email || "",

              targetType: "farmer",
              farmerUID: selectedFarmer.uid,
              farmerEmail: selectedFarmer.email || "",
              farmerName: selectedFarmer.name,

              rubberType: selectedFarmer.type,
              quantity: quantity,
              offeredPrice: price,
              message: message,
              status: "Pending",
              createdAt: serverTimestamp()
          });

        feedback.textContent = "Request sent successfully!";
        feedback.style.color = "green";

        setTimeout(() => {
            window.location.href = "buyer-requests.html";
        }, 1000);

    } catch (error) {
        console.error("Request error:", error);
        feedback.textContent = "Unable to send request. Please try again.";
        feedback.style.color = "red";

    } finally {
        sendButton.disabled = false;
        sendButton.textContent = "Send Request";
    }
};

console.log("Request form function:", typeof window.openFarmerRequest);
console.log("Request modal:", document.getElementById("requestModal"));