import { auth, db } from "./firebase-config.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";
import {
  collection, doc, getDoc, onSnapshot, addDoc, setDoc,
  updateDoc, serverTimestamp, orderBy, query, where
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

const $ = (id) => document.getElementById(id);
const conversationList = $("conversationList");
const messagesBox = $("messages");
const messageInput = $("messageInput");
const messageForm = $("messageForm");
const sendBtn = $("sendBtn");
let currentUser = null;
let currentProfile = {};
let activeConversationId = null;
let activeConversationData = null;
let stopConversationListener = null;
let stopMessagesListener = null;
let conversationCache = [];

function showToast(message) {
  const toast = $("toast");
  toast.textContent = message;
  toast.style.display = "block";
  setTimeout(() => { toast.style.display = "none"; }, 3500);
}
function escapeHtml(value = "") {
  return String(value).replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function displayName(profile = {}) {
  return profile.companyName || profile.name || profile.username || "Rubora user";
}
function formatTime(timestamp) {
  if (!timestamp) return "";
  const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
  return date.toLocaleString([], { dateStyle: "short", timeStyle: "short" });
}
function conversationId(a, b) { return [a, b].sort().join("__"); }

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    alert("Please log in to use messages.");
    window.location.href = "login.html";
    return;
  }
  currentUser = user;
  try {
    const profileSnap = await getDoc(doc(db, "users", user.uid));
    currentProfile = profileSnap.exists() ? profileSnap.data() : {};
    await setDoc(doc(db, "publicProfiles", user.uid), {
      uid: user.uid,
      name: currentProfile.name || currentProfile.username || "Rubora user",
      userType: currentProfile.userType || "user",
      companyName: currentProfile.companyName || "",
      district: currentProfile.district || ""
    });
    listenToConversations();
    const recipientUid = new URLSearchParams(window.location.search).get("to");
    if (recipientUid && recipientUid !== user.uid) await startConversationByUid(recipientUid);
  } catch (error) {
    console.error("Unable to load messaging profile:", error);
    showToast("Could not load your messaging profile. Check Firebase permissions.");
  }
});

function listenToConversations() {
  if (stopConversationListener) stopConversationListener();
  const q = query(collection(db, "conversations"), where("participantIds", "array-contains", currentUser.uid));
  stopConversationListener = onSnapshot(q, (snapshot) => {
    conversationCache = snapshot.docs.map((item) => ({ id: item.id, ...item.data() }));
    conversationCache.sort((a, b) => (b.updatedAt?.toMillis?.() || 0) - (a.updatedAt?.toMillis?.() || 0));
    renderConversationList();
    if (activeConversationId) {
      const updated = conversationCache.find((item) => item.id === activeConversationId);
      if (updated) activeConversationData = updated;
    }
  }, (error) => {
    console.error("Conversation listener error:", error);
    conversationList.innerHTML = '<div class="empty-list">Unable to load conversations. Check Firestore security rules.</div>';
  });
}

function otherParticipant(conversation) {
  const otherUid = (conversation.participantIds || []).find((uid) => uid !== currentUser.uid);
  const info = conversation.participants?.[otherUid] || {};
  return { uid: otherUid, ...info, name: info.name || info.companyName || "Rubora user" };
}
function renderConversationList() {
  if (!conversationCache.length) {
    conversationList.innerHTML = '<div class="empty-list">No conversations yet.<br>Start one using the Message button on a listing.</div>';
    return;
  }
  conversationList.innerHTML = conversationCache.map((c) => {
    const person = otherParticipant(c);
    return `<button class="conversation ${c.id === activeConversationId ? "active" : ""}" data-id="${escapeHtml(c.id)}"><strong>${escapeHtml(person.name)}</strong><small>${escapeHtml(c.lastMessage || "Conversation started")}</small><small>${escapeHtml(person.userType || "Rubora member")} · ${escapeHtml(formatTime(c.updatedAt))}</small></button>`;
  }).join("");
  conversationList.querySelectorAll(".conversation").forEach((button) => button.addEventListener("click", () => openConversation(button.dataset.id)));
}

async function startConversationByUid(uid) {
  try {
    const recipientSnap = await getDoc(doc(db, "publicProfiles", uid));
    if (!recipientSnap.exists()) return showToast("This user has not completed their messaging profile yet. Ask them to sign in and open Messages once.");
    await createOrOpenConversation(uid, recipientSnap.data());
  } catch (error) {
    console.error("Start conversation error:", error);
    showToast("Could not start conversation. Check Firebase rules.");
  }
}
async function createOrOpenConversation(recipientUid, recipientProfile) {
  if (!recipientUid || recipientUid === currentUser.uid) return showToast("You cannot message yourself.");
  const id = conversationId(currentUser.uid, recipientUid);
  const myInfo = { name: displayName(currentProfile), userType: currentProfile.userType || "user" };
  const theirInfo = { name: displayName(recipientProfile), userType: recipientProfile.userType || "user" };
  await setDoc(doc(db, "conversations", id), {
    participantIds: [currentUser.uid, recipientUid].sort(),
    participants: { [currentUser.uid]: myInfo, [recipientUid]: theirInfo },
    updatedAt: serverTimestamp()
  }, { merge: true });
  await openConversation(id);
}
async function openConversation(id) {
  let c = conversationCache.find((item) => item.id === id);
  if (!c) {
    const snap = await getDoc(doc(db, "conversations", id));
    if (!snap.exists()) return showToast("Conversation not found.");
    c = { id, ...snap.data() };
  }
  activeConversationData = c;
  activeConversationId = id;
  const person = otherParticipant(c);
  $("threadName").textContent = person.name;
  $("threadSub").textContent = person.userType || "Rubora member";
  messageInput.disabled = false;
  sendBtn.disabled = false;
  $("chatStatus").textContent = "Connected · Messages update automatically.";
  renderConversationList();
  if (stopMessagesListener) stopMessagesListener();
  const q = query(collection(db, "conversations", id, "messages"), orderBy("createdAt", "asc"));
  stopMessagesListener = onSnapshot(q, (snapshot) => {
    if (snapshot.empty) {
      messagesBox.innerHTML = '<div class="welcome"><i class="bi bi-chat-heart"></i><p>This is the beginning of your conversation. Send a message to get started.</p></div>';
      return;
    }
    messagesBox.innerHTML = snapshot.docs.map((d) => {
      const m = d.data();
      const mine = m.senderId === currentUser.uid;
      return `<div class="bubble ${mine ? "mine" : ""}"><p>${escapeHtml(m.text || "")}</p><time>${mine ? "You" : escapeHtml(person.name)} · ${escapeHtml(formatTime(m.createdAt))}</time></div>`;
    }).join("");
    messagesBox.scrollTop = messagesBox.scrollHeight;
  }, (error) => {
    console.error("Message listener error:", error);
    $("chatStatus").textContent = "Could not load messages. Check Firestore rules.";
  });
}

messageForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const text = messageInput.value.trim();
  if (!text || !activeConversationId || !currentUser) return;
  sendBtn.disabled = true;
  try {
    const ref = doc(db, "conversations", activeConversationId);
    await addDoc(collection(db, "conversations", activeConversationId, "messages"), {
      text, senderId: currentUser.uid, createdAt: serverTimestamp()
    });
    await updateDoc(ref, { lastMessage: text, updatedAt: serverTimestamp() });
    messageInput.value = "";
  } catch (error) {
    console.error("Send message error:", error);
    showToast("Message was not sent: " + error.message);
  } finally {
    sendBtn.disabled = false;
    messageInput.focus();
  }
});

$("backLink").addEventListener("click", (event) => {
  if (currentProfile.userType === "farmer") { event.preventDefault(); window.location.href = "farmer-profile.html"; }
  else if (currentProfile.userType === "buyer") { event.preventDefault(); window.location.href = "buyer-profile.html"; }
});
