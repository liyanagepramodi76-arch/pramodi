import { db, auth } from "./firebase-config.js";

import {
    collection,
    getDocs,
    addDoc,
    serverTimestamp,
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

// =====================================================
// ELEMENTS
// =====================================================

const buyerPriceContainer =
    document.getElementById("buyerPriceContainer");

const searchBuyer =
    document.getElementById("searchBuyer");

const searchPrice =
    document.getElementById("searchPrice");

const districtFilter =
    document.getElementById("districtFilter");


// =====================================================
// STORE BUYER PRICES
// =====================================================

let buyerPrices = [];


// =====================================================
// LOAD BUYER PRICES FROM FIREBASE
// =====================================================

async function loadBuyerPrices() {

    try {

        console.log("DB OBJECT:", db);

        const buyerPricesRef = collection(db, "buyerPrices");

        const querySnapshot = await getDocs(buyerPricesRef);

        buyerPrices = [];

        querySnapshot.forEach((doc) => {

            buyerPrices.push({
                id: doc.id,
                ...doc.data()
            });

        });

        console.log("✅ Buyer prices loaded:", buyerPrices);

        buyerPrices.sort((a, b) => {

            const timeA = a.createdAt?.seconds || 0;
            const timeB = b.createdAt?.seconds || 0;

            return timeB - timeA;

        });

        displayBuyerPrices(buyerPrices);

    } catch (error) {

        console.error("❌ Error loading buyer prices:", error);

        if (buyerPriceContainer) {

            buyerPriceContainer.innerHTML = `
                <div class="col-12 text-center py-5">
                    <i class="bi bi-exclamation-circle fs-1 text-danger"></i>

                    <h4 class="mt-3">
                        Unable to load buyer prices
                    </h4>

                    <p>
                        ${error.message}
                    </p>
                </div>
            `;

        }

    }

}


// =====================================================
// DISPLAY BUYER PRICE CARDS
// =====================================================

function displayBuyerPrices(prices) {

    if (!buyerPriceContainer) {
        return;
    }

    buyerPriceContainer.innerHTML = "";

    if (prices.length === 0) {

        buyerPriceContainer.innerHTML = `
            <div class="col-12">
                <div class="text-center py-5">

                    <i class="bi bi-shop fs-1"></i>

                    <h4 class="mt-3">
                        No Buyer Prices Available
                    </h4>

                    <p>
                        Buyers have not published any prices yet.
                    </p>

                </div>
            </div>
        `;

        return;
    }


    // Find highest price
    const highestPrice = Math.max(
        ...prices.map(item => Number(item.price) || 0)
    );


    prices.forEach((item) => {

        const company =
            item.company || "Unknown Company";

        const district =
            item.district || "Not specified";

        const rubberType =
            item.rubberType || "Not specified";

        const price =
            Number(item.price) || 0;

        const details =
            item.details || "";


        // Best price badge
        const isBestPrice =
            price === highestPrice && prices.length > 1;


        const badge = isBestPrice
            ? `
                <span class="badge bg-warning text-dark">
                    ⭐ Best Price
                </span>
              `
            : `
                <span class="badge bg-success">
                    Available
                </span>
              `;


        const card = document.createElement("div");

        card.className =
            "col-xl-4 col-lg-6 col-md-6";


        card.innerHTML = `
    <div class="buyer-card-v2">

        <div class="buyer-card-header">

            <div class="company-avatar">
                <i class="bi bi-building"></i>
            </div>

            <div class="company-info">
                <h4>${escapeHTML(company)}</h4>

                <div class="location">
                    <i class="bi bi-geo-alt-fill"></i>
                    ${escapeHTML(district)}
                </div>
            </div>

            <div class="price-status">
                ${isBestPrice
                    ? `<span class="best-badge">
                        <i class="bi bi-star-fill"></i> Best
                       </span>`
                    : `<span class="available-badge">
                        Available
                       </span>`
                }
            </div>

        </div>

        <div class="rubber-chip">
            <i class="bi bi-circle-fill"></i>
            ${escapeHTML(rubberType)}
        </div>

        <div class="price-area">

            <span class="price-label">BUYING PRICE</span>

            <div class="main-price">
                <span class="currency">Rs.</span>
                <span class="price-number">
                    ${price.toLocaleString()}
                </span>
                <span class="per-kg">/ kg</span>
            </div>

        </div>

        ${details ? `
            <div class="buyer-details-v2">
                <i class="bi bi-info-circle"></i>

                <div>
                    <span>Additional Details</span>
                    <p>${escapeHTML(details)}</p>
                </div>
            </div>
        ` : ""}

        <div class="card-divider"></div>

        <button
            type="button"
            class="request-btn-v2"
            onclick="openRequest('${escapeAttribute(company)}',
            '${escapeAttribute(item.buyerUID || "")}',
            '${escapeAttribute(item.id)}')">

            <span>Send Request</span>
            <i class="bi bi-arrow-right"></i>
        </button>

        ${item.buyerUID ? `<a href="chat.html?to=${encodeURIComponent(item.buyerUID)}" style="display:block;text-align:center;margin-top:10px;padding:11px 14px;border:1px solid #166534;border-radius:10px;color:#166534;text-decoration:none;font-weight:700;"><i class="bi bi-chat-dots"></i> Message Buyer</a>` : ""}

            </div>
        `;

        buyerPriceContainer.appendChild(card);

    });


    // Re-run AOS animation
    if (typeof AOS !== "undefined") {
        AOS.refresh();
    }

}


// =====================================================
// SEARCH / FILTER
// =====================================================

function filterBuyerPrices() {

    const buyerSearch =
        searchBuyer
            ? searchBuyer.value.trim().toLowerCase()
            : "";

    const priceSearch =
        searchPrice
            ? searchPrice.value.trim()
            : "";

    const selectedDistrict =
        districtFilter
            ? districtFilter.value
            : "all";


    const filtered =
        buyerPrices.filter((item) => {

            const company =
                (item.company || "").toLowerCase();

            const district =
                item.district || "";

            const price =
                Number(item.price) || 0;


            const matchesCompany =
                company.includes(buyerSearch);

            const matchesPrice =
                priceSearch === ""
                || price <= Number(priceSearch);

            const matchesDistrict =
                selectedDistrict === "all"
                || district === selectedDistrict;


            return (
                matchesCompany &&
                matchesPrice &&
                matchesDistrict
            );

        });


    displayBuyerPrices(filtered);

}


// =====================================================
// EVENT LISTENERS
// =====================================================

if (searchBuyer) {

    searchBuyer.addEventListener(
        "input",
        filterBuyerPrices
    );

}

if (searchPrice) {

    searchPrice.addEventListener(
        "input",
        filterBuyerPrices
    );

}

if (districtFilter) {

    districtFilter.addEventListener(
        "change",
        filterBuyerPrices
    );

}


// =====================================================
// HTML SECURITY
// =====================================================

function escapeHTML(value) {

    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


function escapeAttribute(value) {

    return String(value)
        .replace(/\\/g, "\\\\")
        .replace(/'/g, "\\'");
}


// =====================================================
// REQUEST MODAL
// =====================================================

let selectedBuyer = "";
let selectedBuyerUID = "";
let selectedBuyerPriceID = "";


window.openRequest = function (buyer, buyerUID, priceID) {

    selectedBuyer = buyer;
    selectedBuyerUID = buyerUID;
    selectedBuyerPriceID = priceID;

    const buyerName = document.getElementById("buyerName");
    const requestModal = document.getElementById("requestModal");

    if (buyerName) {
        buyerName.innerText = buyer;
    }

    // document.getElementById("buyerName").innerText = buyer;

    document.getElementById("quantity").value = "";
    document.getElementById("price").value = "";

    const message = document.getElementById("message");

    if (message) {
        message.value = "";
    }

    if (requestModal) {
        requestModal.style.display = "flex";
    }
};


window.closeRequest = function () {

    const requestModal =
        document.getElementById("requestModal");

    const successMessage =
        document.getElementById("successMessage");


    if (requestModal) {
        requestModal.style.display = "none";
    }

    if (successMessage) {
        successMessage.style.display = "none";
    }

};


window.sendRequest = async function () {

    if (!auth.currentUser) {
        alert("Please login first.");
        return;
    }

    if (!selectedBuyerUID) {
        alert("Buyer information is missing. Please try again.");
        return;
    }

    const quantity = Number(
        document.getElementById("quantity")?.value
    );

    const price = Number(
        document.getElementById("price")?.value
    );

    const message =
        document.getElementById("message")?.value || "";

    if (!quantity || quantity <= 0 || !price || price <= 0) {
        alert("Please enter a valid quantity and offered price.");
        return;
    }

    try {
        const farmerDoc = await getDoc(
            doc(db, "users", auth.currentUser.uid)
        );

        const farmerData = farmerDoc.exists()
            ? farmerDoc.data()
            : {};

        const farmerName =
            farmerData.personName ||
            farmerData.name ||
            farmerData.username ||
            "Farmer";

            console.log("Farmer document exists:", farmerDoc.exists());
            console.log("Farmer data:", farmerData);
            console.log("Farmer name:", farmerName);

        await addDoc(collection(db, "farmerRequests"), {

            senderUID: auth.currentUser.uid,
            senderName: farmerName,
            senderEmail: auth.currentUser.email,
            senderRole: "farmer",

            recipientUID: selectedBuyerUID,
            recipientRole: "buyer",

            buyer: selectedBuyer,
            buyerPriceID: selectedBuyerPriceID,

            quantity: quantity,
            offeredPrice: price,
            message: message,

            status: "Pending",
            createdAt: serverTimestamp()

        });

        alert("Request sent successfully!");

        document.getElementById("quantity").value = "";
        document.getElementById("price").value = "";
        document.getElementById("message").value = "";

        window.closeRequest();

    } catch (error) {

        console.error("Error sending request:", error);
        alert("Unable to send request: " + error.message);

    }
};




// Close modal when clicking outside

window.addEventListener("click", function (event) {

    const modal =
        document.getElementById("requestModal");

    if (
        modal &&
        event.target === modal
    ) {

        closeRequest();

    }

});


// =====================================================
// START
// =====================================================

loadBuyerPrices();



/*
import { db, auth } from "./firebase-config.js";

import {
    collection,
    addDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";


// ================= SEARCH =================

// ================= SEARCH & FILTER =================

const searchBuyer = document.getElementById("searchBuyer");
const searchPrice = document.getElementById("searchPrice");
const districtFilter = document.getElementById("districtFilter");

const cards = document.querySelectorAll(".search-card");

if (searchBuyer && searchPrice && districtFilter) {

    searchBuyer.addEventListener("input", filterCards);

    searchPrice.addEventListener("input", filterCards);

    districtFilter.addEventListener("change", filterCards);

}

function filterCards() {

    const buyer = searchBuyer.value.trim().toLowerCase();

    const minimumPrice = parseFloat(searchPrice.value) || 0;

    const district = districtFilter.value;

    cards.forEach(card => {

        const company = card.dataset.company.toLowerCase();

        const cardDistrict = card.dataset.district;

        const cardPrice = parseFloat(card.dataset.price);

        const buyerMatch =
            company.includes(buyer);

        const districtMatch =
            district === "all" ||
            district === cardDistrict;

        const priceMatch =
            minimumPrice === 0 ||
            cardPrice >= minimumPrice;

        card.parentElement.style.display =
            buyerMatch &&
            districtMatch &&
            priceMatch
                ? "block"
                : "none";

    });

}



// ================= OPEN MODAL =================

function openRequest(company){

    document.getElementById("buyerName").textContent = company;

    document.getElementById("quantity").value = "";

    document.getElementById("price").value = "";

    document.getElementById("message").value = "";

    document.getElementById("requestModal").style.display = "flex";

}


// ================= CLOSE MODAL =================

function closeRequest() {

    document.getElementById("requestModal").style.display = "none";

}


// ================= SEND REQUEST =================

async function sendRequest() {

    if (!auth.currentUser) {

        alert("Please login first.");

        return;

    }

    const buyer = document.getElementById("buyerName").textContent;

    const quantity = document.getElementById("quantity").value;

    const price = document.getElementById("price").value;

    const message = document.getElementById("message").value;

    if (!quantity || !price) {

        alert("Please enter quantity and offered price.");

        return;

    }

    try {

        await addDoc(collection(db, "farmerRequests"), {

            buyer: buyer,

            sender: auth.currentUser.email,

            senderUID: auth.currentUser.uid,

            quantity: Number(quantity),

            offeredPrice: Number(price),

            message: message,

            status: "Pending",

            createdAt: serverTimestamp()

        });

        alert(" Request sent successfully!");

        document.getElementById("quantity").value = "";

        document.getElementById("price").value = "";

        document.getElementById("message").value = "";

        closeRequest();

    }

    catch (error) {

        console.error(error);

        alert(error.message);

    }

}


// Make functions available to HTML onclick

window.openRequest = openRequest;

window.closeRequest = closeRequest;

window.sendRequest = sendRequest;


window.onclick = function(event){

    const modal = document.getElementById("requestModal");

    if(event.target === modal){

        modal.style.display = "none";

    }

};
*/