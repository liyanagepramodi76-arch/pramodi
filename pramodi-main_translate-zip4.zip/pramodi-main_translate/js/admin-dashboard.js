
import { auth, db } from "./firebase-config.js";

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

import {
    collection,
    getDocs
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


// ================= ADMIN SECURITY =================

onAuthStateChanged(auth, async (user) => {

    if (!user) {
        window.location.replace("login.html");
        return;
    }

    try {

        const tokenResult = await user.getIdTokenResult(true);

        if (tokenResult.claims.admin !== true) {

            alert("Access denied! Admin permission required.");

            await signOut(auth);

            window.location.replace("login.html");

            return;
        }

        console.log("Admin verified:", user.email);

        loadDashboardData();

    } catch (error) {

        console.error("Admin verification failed:", error);

        await signOut(auth);

        window.location.replace("login.html");

    }

});


// ================= LOAD DASHBOARD DATA =================

async function loadDashboardData() {

    try {

        const usersSnapshot = await getDocs(collection(db, "users"));

        let farmers = 0;
        let buyers = 0;

        usersSnapshot.forEach((document) => {

            const userData = document.data();

            if (userData.userType === "farmer") {
                farmers++;
            }

            else if (userData.userType === "buyer") {
                buyers++;
            }

        });

        document.getElementById("totalFarmers").textContent = farmers;
        document.getElementById("totalBuyers").textContent = buyers;


        // Published stocks
        try {

            const stocksSnapshot = await getDocs(
                collection(db, "publishedStocks")
            );

            document.getElementById("totalStocks").textContent =
                stocksSnapshot.size;

        } catch (error) {

            console.error("Stock loading error:", error);
            document.getElementById("totalStocks").textContent = "N/A";

        }


        // Buyer prices
        try {

            const pricesSnapshot = await getDocs(
                collection(db, "buyerPrices")
            );

            document.getElementById("totalPrices").textContent =
                pricesSnapshot.size;

        } catch (error) {

            console.error("Price loading error:", error);
            document.getElementById("totalPrices").textContent = "N/A";

        }

        console.log("Dashboard data loaded successfully.");

    } catch (error) {

        console.error("Dashboard loading error:", error);

        alert("Unable to load dashboard data. Please check Firebase permissions.");

    }

}


// ================= LOGOUT =================

const logoutBtn = document.getElementById("logoutBtn");

logoutBtn.addEventListener("click", async () => {

    const confirmLogout = confirm("Are you sure you want to logout?");

    if (confirmLogout) {

        try {

            await signOut(auth);

            window.location.replace("login.html");

        } catch (error) {

            console.error("Logout error:", error);

            alert("Unable to logout. Please try again.");

        }

    }

});


// ================= MOBILE SIDEBAR =================

const menuToggle = document.getElementById("menuToggle");

const adminSidebar = document.getElementById("adminSidebar");

menuToggle.addEventListener("click", () => {

    adminSidebar.classList.toggle("show");

});


// Close sidebar after clicking a menu link

document.querySelectorAll(".admin-nav .nav-item").forEach((link) => {

    link.addEventListener("click", () => {

        adminSidebar.classList.remove("show");

    });

});


// ================= DARK MODE =================

const themeToggle = document.getElementById("themeToggle");

const savedTheme = localStorage.getItem("rubora-admin-theme");

if (savedTheme === "dark") {

    document.body.classList.add("dark-mode");

    themeToggle.innerHTML = '<i class="bi bi-sun"></i>';

}

themeToggle.addEventListener("click", () => {

    document.body.classList.toggle("dark-mode");

    const isDark = document.body.classList.contains("dark-mode");

    localStorage.setItem(
        "rubora-admin-theme",
        isDark ? "dark" : "light"
    );

    themeToggle.innerHTML = isDark
        ? '<i class="bi bi-sun"></i>'
        : '<i class="bi bi-moon-stars"></i>';

});
